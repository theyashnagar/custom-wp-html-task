const menuBtn = document.getElementById('mobile-memu');
const menu = document.getElementsByClassName('menu-list');

menuBtn.onclick = function () {
    Array.from(menu).forEach((menu) => {
      if (menu.style.display !== "none") {
        menu.style.display = "none";
      } else {
        menu.style.display = "block";
      }
  })
};