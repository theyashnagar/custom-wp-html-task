<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/style.css">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"><link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <!-- Google Fonts -->

    <title>Document</title>
</head>
<body>
    <!-- SECTION 1  -->
    <section class="section-1">
        <div class="hero">
            <div class="navbar">
                <div class="logo">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.svg" alt="">
                </div>
                <div class="menu">
                    <ul>
                        <li id="mobile-memu"><i class="fa-solid fa-bars"></i></li>
                        <li class="menu-list"><a href="#">HOME</a></li>
                        <li class="menu-list"><a href="#">ABOUT</a></li>
                        <li class="menu-list"><a href="#">SERVICES</a></li>
                        <li class="menu-list"><a href="#">NEWS</a></li>
                        <li class="menu-list"><a href="#">CONTACT US</a></li>
                        <li class="menu-list"><a href="#"><span><i class="fa-solid fa-user"></i></span> LOGIN</a></li>
                        <li class="menu-list"><a href="#"><span><i class="fa-solid fa-magnifying-glass"></i></span></a></li>
                    </ul>
                </div>
            </div>

            <div class="hero-section">
                <div class="hero-details">
                    <h2>Progress & Sucess</h2>
                    <h1>CURRENCY</h1>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Assumenda sint blanditiis ipsum dolor sit amet consectetur</p>
                    <div class="btn-sec">
                        <div>
                            <a href="#" class="cbtn"><i class="fa-solid fa-circle-dollar-to-slot"></i> DISCOVER NOW</a>
                        </div>
                        <div class="slider-btn">
                            <i class="fa-solid fa-chevron-left"></i>
                            <i class="fa-solid fa-chevron-right"></i>
                        </div>
                    </div>
                </div>
                <div class="hero-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hero-img.png" alt="">
                </div>
            </div>
        </div>
    </section>
    <!-- SECTION 1  -->


    <!-- SECTION 2  -->
    <section class="section-2">
        <div class="sec-2-img">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hero-img.png" alt="">
        </div>
        <div class="sec-2-content">
            <h6>ABOUT US</h6>
            <h1>WELCOME TO OUR DEGITALEX</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sed culpa ducimus iure qui mollitia voluptatibus esse consequuntur pariatur labore, a nobis amet perferendis. Quod recusandae reprehenderit porro nisi numquam aspernatur!</p>
            <a href="" class="cbtn mt-50">READ MORE</a>
        </div>
    </section>
    <!-- SECTION 2  -->
    
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/custom-script.js"></script>
</body>
</html>